package com.auca.domain;


public enum Eregistration {

	PENDING,
	ADMITTED,
	REJECTED
}
