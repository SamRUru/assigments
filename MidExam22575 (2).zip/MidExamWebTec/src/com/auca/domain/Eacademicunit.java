package com.auca.domain;

public enum Eacademicunit {
	PROGRAM,
	FACULTY,
	DEPARTMENT
}
